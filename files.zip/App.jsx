import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "stock-bank-v2";
const TRADES_KEY = "stock-trades-v1";
const PORTFOLIO_KEY = "stock-portfolio-v1";
const DAILY_KEY = "stock-daily-v1";
const NOTION_DAILY_DB = "09405c1f-d231-4205-849b-cf19d7ca4664";

const NOTION_STOCKS = [
  { id: 1, ticker: "RKLB", name: "Rocket Lab USA", sector: "space", layer: "growth", risk: "high", currentPrice: 75.67, targetPrice: 95, weight: 13, pe: null, analystTarget: 74.5, earningsDate: "2026-05-12", thesis: "החברה הציבורית הכי קרובה ל-SpaceX — שיגורים + ייצור לוויינים + רכיבים. Backlog של $1.85B עם חוזה SDA של $816M.", fundamental: "הכנסות $602M, +38% YoY, gross margin לא-GAAP 44.3%. שיפור עקבי ב-margin. טיל Neutron עוכב לQ4 2026.", technical: "ערוץ עולה עם HH/HL. התנגדות ראשית ב-$80. קונצנזוס Buy.", addedAt: "2026-03-16T13:14:38.465Z" },
  { id: 2, ticker: "ASTS", name: "AST SpaceMobile", sector: "space", layer: "speculative", risk: "high", currentPrice: 86.5, targetPrice: 139, weight: 6, pe: null, analystTarget: 88.5, earningsDate: "2026-05-06", thesis: "רשת סלולרית מהחלל לטלפונים רגילים. Moonshot מוחלט — גייסה $3.5B ב-2025.", fundamental: "הכנסות $70.9M, +641% YoY. מדריך Q1 2026: $31.88M בלבד.", technical: "ירידה 34% מהשיא $129. תמיכה ב-$85.", addedAt: "2026-03-16T13:15:37.137Z" },
  { id: 3, ticker: "PL", name: "Planet Labs", sector: "space", layer: "growth", risk: "medium", currentPrice: 24.79, targetPrice: 35, weight: 8, pe: null, analystTarget: 32, earningsDate: "2026-06-15", thesis: "צי הלוויינים הגדול בעולם. Backlog חצה $734M.", fundamental: "עדיין מפסידה. תחרות מ-BlackSky ו-Maxar.", technical: "ריבאונד מהתחתית, מעל MA50.", addedAt: "2026-03-16T13:15:37.137Z" },
  { id: 4, ticker: "BKSY", name: "BlackSky Technology", sector: "space", layer: "waiting", risk: "high", currentPrice: 23.93, targetPrice: 42, weight: 5, pe: null, analystTarget: 27, earningsDate: "2026-05-15", thesis: "ISR ביטחוני עם Gen-3 לוויינים ב-35cm רזולוציה.", fundamental: "הכנסות $107M, +4% YoY. Guidance 2026: $120-145M.", technical: "⚠️ נדרשים 2 רבעונות חזקים לפני כניסה.", addedAt: "2026-03-16T13:15:37.137Z" },
  { id: 5, ticker: "RDW", name: "Redwire Corporation", sector: "space", layer: "waiting", risk: "high", currentPrice: 9.59, targetPrice: 14, weight: 4, pe: null, analystTarget: 12, earningsDate: "2026-05-20", thesis: "תשתית וחומרה לחלליות — picks and shovels.", fundamental: "לא רווחית. חשיפה גבוהה לתקציבי ממשל.", technical: "⚠️ שבירה מעל $10 נדרשת.", addedAt: "2026-03-16T13:15:37.137Z" },
  { id: 6, ticker: "ITA", name: "iShares Aerospace & Defense ETF", sector: "defense", layer: "core", risk: "low", currentPrice: 229.34, targetPrice: 270, weight: 10, pe: null, analystTarget: 270, earningsDate: null, thesis: "ETF של BlackRock. AUM $16B. חשיפה רחבה לסקטור הגנה.", fundamental: "52W: $129-$250. YTD +11.7%. Expense Ratio 0.38%.", technical: "קרוב לשיא. מתחזק על רקע עליית תקציבי NATO.", addedAt: "2026-03-16T13:29:00.359Z" },
  { id: 7, ticker: "UFO", name: "Procure Space ETF", sector: "space", layer: "core", risk: "medium", currentPrice: 42.67, targetPrice: 55, weight: 10, pe: 27.87, analystTarget: 55, earningsDate: null, thesis: "ETF חלל עוקב S-Network Space Index. AUM $364M.", fundamental: "52W: $18-$48. YTD +66.44%. Expense Ratio 0.75%.", technical: "Strong Buy כל הטווחים. קרוב לשיא 52W.", addedAt: "2026-03-16T13:22:43.020Z" },
  { id: 8, ticker: "NLR", name: "VanEck Uranium & Nuclear ETF", sector: "energy", layer: "growth", risk: "medium", currentPrice: 136.63, targetPrice: 165, weight: 8, pe: null, analystTarget: 146.47, earningsDate: null, thesis: "ETF אורניום ואנרגיה גרעינית. כריית אורניום, בניית כורים.", fundamental: "52W: $64-$168. Net Flows +$2.7B. Top: LEU, BWXT, NXE.", technical: "ירידה משיא $168. תמיכה $136.", addedAt: "2026-03-16T16:12:19.408Z" },
  { id: 9, ticker: "TAN", name: "Invesco Solar ETF", sector: "energy", layer: "growth", risk: "medium", currentPrice: 55.38, targetPrice: 70, weight: 8, pe: 22.79, analystTarget: 65, earningsDate: null, thesis: "ETF סולרי. ~35 חברות גלובליות. AUM $1.57B.", fundamental: "52W: $25-$61. 1Y Return +72.58%. Beta 2.14.", technical: "ממוצעים SELL קצר. תמיכה $54. שבירה מעל $61.", addedAt: "2026-03-16T16:12:19.408Z" },
  { id: 10, ticker: "VST", name: "Vistra Corp", sector: "energy", layer: "core", risk: "high", currentPrice: 159, targetPrice: 225, weight: 9, pe: 18, analystTarget: 234, earningsDate: "2026-05-07", thesis: "ספקית חשמל גרעיני לחברות הטק. חוזי 20 שנה עם מטא ואמזון.", fundamental: "EBITDA 2025 $5.91B. הנחיה 2026: $7.4-7.8B. 100% הכנסות מגודרות.", technical: "ירידה 28% מהשיא $219. תמיכה $145-155. יעד אנליסטים $234.", addedAt: "2026-03-17T00:00:00.000Z" },
  { id: 11, ticker: "CEG", name: "Constellation Energy", sector: "energy", layer: "waiting", risk: "medium", currentPrice: 288, targetPrice: 395, weight: 9, pe: 27, analystTarget: 406, earningsDate: "2026-03-31", thesis: "המפיקה הגדולה בעולם של חשמל גרעיני נקי. חוזי 20 שנה עם מיקרוסופט ומטא.", fundamental: "מכפיל עתידי 27. תוספת תזרים $2B מקאלפיין. דיבידנד גדל 10%/שנה.", technical: "⚠️ לא להיכנס לפני 31/3 — הנחיית קאלפיין.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 12, ticker: "CCJ", name: "Cameco Corporation", sector: "energy", layer: "waiting", risk: "high", currentPrice: 110, targetPrice: 123, weight: 5, pe: 35, analystTarget: 120, earningsDate: "2026-05-02", thesis: "שרשרת גרעין שלמה — כרייה, עיבוד דלק, ובניית כורים.", fundamental: "הכנסות $3.48B. מזומן $1.2B, חוב $1B. חוזים ל-230M פאונד אורניום.", technical: "⚠️ טריגר: אורניום מעל $90/פאונד + מקארתור ריבר.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 13, ticker: "UNH", name: "UnitedHealth Group", sector: "health", layer: "waiting", risk: "high", currentPrice: 285, targetPrice: 387, weight: 5, pe: 16, analystTarget: 387, earningsDate: "2026-04-15", thesis: "Value play — ביטוח בריאות מוביל עם זרוע Optum טכנולוגית. P/E 16x — שפל היסטורי.", fundamental: "הכנסות מוכוונות $439B. EPS מוכוון $17.75+. FCF $18B+.", technical: "⚠️ ירידה ~50% מהשיא. חקירת DOJ פעילה.", addedAt: "2026-03-17T19:16:23.542Z" },
  { id: 14, ticker: "LLY", name: "Eli Lilly", sector: "health", layer: "growth", risk: "medium", currentPrice: 916, targetPrice: 1255, weight: 7, pe: 43.5, analystTarget: 1255, earningsDate: "2026-04-30", thesis: "מנהיגת GLP-1 עם Mounjaro ו-Zepbound. שוק ההשמנה בצמיחה מבנית.", fundamental: "Q4 הכנסות $19.3B +43% YoY. Mounjaro $7.4B. מרג'ין גולמי 83.2%.", technical: "ירדה 13% מתחילת 2026. תמיכה $920-950.", addedAt: "2026-03-17T19:16:23.542Z" },
  { id: 15, ticker: "LUNR", name: "Intuitive Machines", sector: "space", layer: "waiting", risk: "high", currentPrice: 17.6, targetPrice: 24, weight: 6, pe: null, analystTarget: 22, earningsDate: "2026-03-19", thesis: "שחקן מרכזי בכלכלת הירח ותכנית Artemis.", fundamental: "רכישת Lanteris ב-$800M. הון עצמי שלילי.", technical: "⚠️ דוח 19/3 — קטליסט מרכזי.", addedAt: "2026-03-16T13:15:37.137Z" },
  { id: 16, ticker: "IRDM", name: "Iridium Communications", sector: "space", layer: "core", risk: "low", currentPrice: 20, targetPrice: 25, weight: 9, pe: 22, analystTarget: 25.4, earningsDate: "2026-04-22", thesis: "66 לוויינים, כיסוי גלובלי מלא, חוזים ממשלתיים ודיבידנד.", fundamental: "הכנסות $871.7M, צמיחה 5%. Guidance 2026: 0-2%.", technical: "קונצנזוס HOLD. אפסייד ~25%.", addedAt: "2026-03-16T13:15:37.137Z" },
  { id: 17, ticker: "JNJ", name: "Johnson & Johnson", sector: "health", layer: "core", risk: "medium", currentPrice: 237.88, targetPrice: 265, weight: 5, pe: 15.5, analystTarget: 245, earningsDate: "2026-04-16", thesis: "New J&J ממוקדת Innovative Medicine ו-MedTech. קטליזטור: OTTAVA רובוטיקה 2026.", fundamental: "הכנסות 2025 $94.2B +6%. מכוון מעל $100B ב-2026. FCF $19.7B.", technical: "קרובה לשיא $251. תמיכה $235-240.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 18, ticker: "NVDA", name: "NVIDIA Corporation", sector: "chips", layer: "core", risk: "medium", currentPrice: 181.2, targetPrice: 250, weight: 13, pe: 40, analystTarget: 220, earningsDate: "2026-05-28", thesis: "מלך ה-AI chips. 92% נתח שוק GPU. Data Center 91% מהמכירות.", fundamental: "הכנסות Q4 $68.1B +73% YoY. Guidance Q1 FY27: $78B.", technical: "52W: $86-$212. rangebound ב-2026. תמיכה $160.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 19, ticker: "MU", name: "Micron Technology", sector: "chips", layer: "growth", risk: "high", currentPrice: 461.73, targetPrice: 500, weight: 7, pe: 28, analystTarget: 140, earningsDate: "2026-03-18", thesis: "ה-HBM play הדומיננטי. HBM4 לNVIDIA Vera Rubin.", fundamental: "הכנסות FY25 $37.4B +49%. רווחים קפצו 997%.", technical: "52W: $228-$462. נסחרת בשיא. תמיכה $420.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 20, ticker: "AVGO", name: "Broadcom Inc.", sector: "chips", layer: "core", risk: "medium", currentPrice: 315.93, targetPrice: 400, weight: 11, pe: 38, analystTarget: 260, earningsDate: "2026-06-05", thesis: "מלך custom ASICs. Google TPU, Meta, Apple. $100B AI chips ב-FY2027.", fundamental: "Market cap $1.54T. EBITDA margin 54.67%. דיבידנד $0.65.", technical: "52W: $228-$414. נסחרת $330 — 20% מתחת לשיא.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 21, ticker: "INTC", name: "Intel Corporation", sector: "chips", layer: "speculative", risk: "high", currentPrice: 45.03, targetPrice: 55, weight: 4, pe: null, analystTarget: 25, earningsDate: "2026-04-24", thesis: "הימור turnaround על Intel 18A foundry. Taiwan risk מועיל.", fundamental: "הכנסות Q4 $13.7B. Foundry loss $2.5B. חוב $44B.", technical: "⚠️ upside/downside בינארי — מקס 5%.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 22, ticker: "ON", name: "ON Semiconductor", sector: "chips", layer: "growth", risk: "medium", currentPrice: 61, targetPrice: 75, weight: 7, pe: 20, analystTarget: 65, earningsDate: "2026-04-28", thesis: "מלך SiC/GaN לרכבים חשמליים ו-data centers. FCF $1.4B.", fundamental: "הכנסות FY25 $6B. Gross margin 38.4%. Buyback $6B.", technical: "52W: $31-$73. תמיכה $55.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 23, ticker: "CEVA", name: "CEVA, Inc.", sector: "chips", layer: "speculative", risk: "high", currentPrice: 18.5, targetPrice: 30, weight: 2, pe: null, analystTarget: 26, earningsDate: "2026-05-06", thesis: "IP royalty play על Edge AI. 400+ לקוחות. Gross margin 87%.", fundamental: "הכנסות 2025 $109.6M. הפסד נקי $10.6M. Market cap $517M.", technical: "⚠️ בתחתית range. ירדה 39%. מינימום עלייה נדרש.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 24, ticker: "MTSI", name: "MACOM Technology Solutions", sector: "chips", layer: "growth", risk: "medium", currentPrice: 225, targetPrice: 260, weight: 4, pe: 45, analystTarget: 240, earningsDate: "2026-04-30", thesis: "RF/Photonics על 5G ו-defense. שותפה ב-ACC-MSA עם NVIDIA.", fundamental: "הכנסות Q1 FY26 $271.6M (beat). EBITDA margin 19.95%.", technical: "ATH $258.98 ב-2/3. נסחרת $225 — 13% מהשיא.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 25, ticker: "ONTO", name: "Onto Innovation Inc.", sector: "chips", layer: "growth", risk: "medium", currentPrice: 189, targetPrice: 275, weight: 6, pe: 22, analystTarget: 275, earningsDate: "2026-05-08", thesis: "ציוד metrology לשבבי HBM ו-advanced packaging. TSMC פרס.", fundamental: "הכנסות Q4 $266.9M. Forward PEG 1.13x — דיסקאונט.", technical: "52W: $85-$232. עלתה 43% ב-12 חודשים. תמיכה $165.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 26, ticker: "KTOS", name: "Kratos Defense", sector: "defense", layer: "growth", risk: "high", currentPrice: 87, targetPrice: 110, weight: 8, pe: 60, analystTarget: 105, earningsDate: "2026-05-07", thesis: "XQ-58 Valkyrie רחפן קרבי זול לפנטגון. עלתה 280% בשנה.", fundamental: "הכנסות $1.35B +18.5%. Guidance 2026: +21%. 10 Buy.", technical: "Stop Loss $78. ⚠️ כניסה רק בתיקון.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 27, ticker: "AVAV", name: "AeroVironment", sector: "defense", layer: "growth", risk: "high", currentPrice: 195, targetPrice: 295, weight: 7, pe: 35, analystTarget: 260, earningsDate: "2026-06-10", thesis: "Switchblade, Puma, Raven — מוכחים קרבית. Backlog $1.1B.", fundamental: "Guidance $2B. Gross margin ירד מ-39% ל-22%.", technical: "תמיכה $195. אפסייד 85%.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 28, ticker: "RCAT", name: "Red Cat Holdings", sector: "defense", layer: "speculative", risk: "high", currentPrice: 16, targetPrice: 20.75, weight: 4, pe: null, analystTarget: 20.75, earningsDate: "2026-04-15", thesis: "Black Widow NDAA-compliant לNATO. צמיחה 1842% YoY.", fundamental: "EPS -$0.16. Microcap.", technical: "⚠️ תמיכה $15. שבירה מעל $18 חיובית.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 29, ticker: "LHX", name: "L3Harris Technologies", sector: "defense", layer: "core", risk: "low", currentPrice: 215, targetPrice: 255, weight: 8, pe: 18, analystTarget: 245, earningsDate: "2026-04-29", thesis: "Electronic warfare, counter-UAS, תקשורת. מגן תיק עם דיבידנד.", fundamental: "הכנסות $21B. FCF חזק.", technical: "מעל MA200. אפסייד 18%.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 30, ticker: "LMT", name: "Lockheed Martin", sector: "defense", layer: "core", risk: "low", currentPrice: 490, targetPrice: 510, weight: 7, pe: 18, analystTarget: 520, earningsDate: "2026-04-22", thesis: "Backlog $194B. FCF $6.5B. דיבידנד $3B. ליבה בלבד.", fundamental: "הכנסות $75B. Q2 2025 miss חריף.", technical: "Hold. אפסייד 4% בלבד.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 31, ticker: "CACI", name: "CACI International", sector: "defense", layer: "growth", risk: "medium", currentPrice: 560, targetPrice: 650, weight: 6, pe: 22, analystTarget: 625, earningsDate: "2026-04-30", thesis: "Electronic warfare, cyber, counter-UAS. קריטית לתשתית.", fundamental: "הכנסות $7.8B. FCF חזק. סיכון DOGE.", technical: "אפסייד 16%.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 32, ticker: "ESLT", name: "Elbit Systems", sector: "defense", layer: "waiting", risk: "high", currentPrice: 769, targetPrice: 630, weight: 5, pe: 78, analystTarget: 540, earningsDate: "2026-05-20", thesis: "פונדמנטל מצוין, עסקאות אירופה גדלות. מחיר מעל יעד.", fundamental: "הכנסות $6.83B +14%. P/E 78x.", technical: "⚠️ כניסה בלבד ב-$600-630.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 33, ticker: "PLTR", name: "Palantir Technologies", sector: "defense", layer: "speculative", risk: "high", currentPrice: 154.0, targetPrice: 186, weight: 6, pe: 167, analystTarget: 100, earningsDate: "2026-05-05", thesis: "AI OS של הפנטגון. Rule of 40: 127%. כניסה אידיאלית $130-135.", fundamental: "$1.41B +70% YoY. Guidance 2026: $7.2B.", technical: "⚠️ תמיכה $140. בבדיקה.", addedAt: "2026-03-18T00:00:00.000Z" },
  { id: 34, ticker: "MRNA", name: "Moderna, Inc.", sector: "health", layer: "growth", risk: "high", currentPrice: 52.36, targetPrice: null, weight: null, pe: null, analystTarget: 65, earningsDate: "2026-04-30", thesis: "תבנית Cup and Handle. תמיכה חזקה ב-$50. מגמה עולה.", fundamental: "Market cap $20.62B. דוח רווחים בעוד 42 ימים.", technical: "Cup and Handle | תמיכה $50 | מעל MA150 | ATR 3.54 (6.76%)", addedAt: "2026-03-19T00:00:00.000Z" },
];

const SECTORS = {
  energy:     { label: "אנרגיה",   icon: "⚡",  color: "#F97316", owner: "אייל" },
  space:      { label: "חלל",      icon: "🚀",  color: "#818CF8", owner: "גיא"  },
  defense:    { label: "הגנה",     icon: "🛡️",  color: "#38BDF8", owner: "גיא"  },
  health:     { label: "בריאות",   icon: "🏥",  color: "#34D399", owner: "רוני" },
  chips:      { label: "שבבים",    icon: "💾",  color: "#F472B6", owner: "רוני" },
  financials: { label: "פיננסים",  icon: "🏦",  color: "#FBBF24", owner: "רוני" },
  materials:  { label: "מטריאלס", icon: "⛏️",  color: "#A78BFA", owner: "אייל" },
};

const RISK_CONFIG = {
  low:    { label: "נמוך",   color: "#10B981", bg: "#10B98120" },
  medium: { label: "בינוני", color: "#F59E0B", bg: "#F59E0B20" },
  high:   { label: "גבוה",   color: "#EF4444", bg: "#EF444420" },
};

const LAYER_CONFIG = {
  core:        { label: "ליבה",       color: "#6366F1", desc: "40-50%" },
  growth:      { label: "צמיחה",      color: "#10B981", desc: "30-35%" },
  speculative: { label: "ספקולטיבי", color: "#EF4444", desc: "15-25%" },
  waiting:     { label: "המתנה",      color: "#F59E0B", desc: "ממתין לטריגר" },
};

const MEMBERS = [
  { id: "eyal", name: "אייל", color: "#F97316", avatar: "א" },
  { id: "guy",  name: "גיא",  color: "#818CF8", avatar: "ג" },
  { id: "roni", name: "רוני", color: "#34D399", avatar: "ר" },
];

const PERF_PERIODS = ["1D","5D","1M","6M","YTD","1Y","5Y","10Y"];

// ─────────────────────────────────────────────
// SMALL HELPERS
// ─────────────────────────────────────────────
function Badge({ label, color, bg }) {
  return (
    <span style={{ background: bg || `${color}20`, color, borderRadius: 5, padding: "2px 8px", fontSize: 11, whiteSpace: "nowrap" }}>
      {label}
    </span>
  );
}

function MemberAvatar({ member, size = 28 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: `${member.color}30`, border: `1.5px solid ${member.color}`,
      display: "flex", alignItems: "center", justifyContent: "center",
      color: member.color, fontSize: size * 0.42, fontWeight: 700
    }}>{member.avatar}</div>
  );
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr) - new Date();
  return Math.ceil(d / 86400000);
}

// ─────────────────────────────────────────────
// PERFORMANCE BAR  (like the screenshot)
// ─────────────────────────────────────────────
function PerfBar({ perf }) {
  if (!perf) return null;
  return (
    <div style={{
      display: "flex", gap: 2, background: "#0A0D14",
      borderRadius: 8, padding: "10px 16px", marginTop: 12,
      borderTop: "1px solid #1F2937", flexWrap: "wrap"
    }}>
      {PERF_PERIODS.map(p => {
        const v = perf[p];
        if (v === undefined) return (
          <div key={p} style={{ flex: "0 0 auto", textAlign: "center", padding: "0 12px" }}>
            <div style={{ color: "#4B5563", fontSize: 10, marginBottom: 3 }}>{p}</div>
            <div style={{ color: "#374151", fontSize: 12, fontFamily: "monospace" }}>—</div>
          </div>
        );
        const pos = v >= 0;
        return (
          <div key={p} style={{ flex: "0 0 auto", textAlign: "center", padding: "0 12px", borderLeft: p !== "1D" ? "1px solid #1F2937" : "none" }}>
            <div style={{ color: "#6B7280", fontSize: 10, marginBottom: 3 }}>{p}</div>
            <div style={{ color: pos ? "#10B981" : "#EF4444", fontSize: 13, fontFamily: "'Space Mono', monospace", fontWeight: 700 }}>
              {pos ? "+" : ""}{v.toFixed(2)}%
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────
// STOCK ROW
// ─────────────────────────────────────────────
function StockRow({ stock, onDelete, portfolioData }) {
  const [expanded, setExpanded] = useState(false);
  const sector = SECTORS[stock.sector] || { label: stock.sector, icon: "📊", color: "#6B7280" };
  const risk = RISK_CONFIG[stock.risk];
  const layer = LAYER_CONFIG[stock.layer];
  const upside = stock.targetPrice && stock.currentPrice
    ? (((stock.targetPrice - stock.currentPrice) / stock.currentPrice) * 100).toFixed(1)
    : null;
  const days = daysUntil(stock.earningsDate);
  const urgentEarnings = days !== null && days <= 14 && days >= 0;

  return (
    <div style={{ background: expanded ? "#0D1117" : "#080B12", border: `1px solid ${expanded ? sector.color + "40" : "#1F2937"}`, borderRadius: 10, marginBottom: 6, transition: "all 0.2s" }}>
      {/* ROW */}
      <div onClick={() => setExpanded(!expanded)} style={{ display: "grid", gridTemplateColumns: "76px 1fr 90px 88px 76px 70px 70px 34px", alignItems: "center", padding: "12px 14px", gap: 10, cursor: "pointer" }}>
        {/* Ticker */}
        <div>
          <div style={{ fontFamily: "'Space Mono', monospace", color: "#F9FAFB", fontWeight: 700, fontSize: 14 }}>{stock.ticker}</div>
          <div style={{ color: sector.color, fontSize: 10, marginTop: 1 }}>{sector.icon} {sector.label}</div>
        </div>
        {/* Name + earnings */}
        <div>
          <div style={{ color: "#D1D5DB", fontSize: 12 }}>{stock.name}</div>
          {days !== null && (
            <div style={{ color: urgentEarnings ? "#F59E0B" : "#4B5563", fontSize: 10, marginTop: 1 }}>
              {urgentEarnings ? "⚡ " : "📅 "}דוח {days === 0 ? "היום" : `בעוד ${days}י`}
            </div>
          )}
        </div>
        {/* Risk */}
        <Badge label={risk.label} color={risk.color} bg={risk.bg} />
        {/* Layer */}
        <Badge label={layer.label} color={layer.color} />
        {/* Upside */}
        <div style={{ fontFamily: "'Space Mono', monospace", color: upside > 0 ? "#10B981" : upside < 0 ? "#EF4444" : "#4B5563", fontSize: 12 }}>
          {upside ? `${upside > 0 ? "+" : ""}${upside}%` : "—"}
        </div>
        {/* PE */}
        <div style={{ color: "#6B7280", fontSize: 11, fontFamily: "monospace" }}>
          {stock.pe ? `P/E ${stock.pe}x` : "—"}
        </div>
        {/* Analyst target */}
        <div style={{ color: "#34D399", fontSize: 11, fontFamily: "monospace" }}>
          {stock.analystTarget ? `$${stock.analystTarget}` : "—"}
        </div>
        {/* Delete */}
        <button onClick={e => { e.stopPropagation(); onDelete(stock.id); }} style={{ background: "none", border: "none", color: "#2D3748", cursor: "pointer", fontSize: 14, padding: 2 }}
          onMouseEnter={e => e.target.style.color = "#EF4444"} onMouseLeave={e => e.target.style.color = "#2D3748"}>✕</button>
      </div>

      {/* EXPANDED */}
      {expanded && (
        <div style={{ padding: "0 14px 14px", borderTop: "1px solid #1F2937" }}>
          {/* Performance bar */}
          <PerfBar perf={stock.perf} />
          {/* Details grid */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginTop: 14 }}>
            {[
              { label: "תזה", value: stock.thesis, color: "#818CF8" },
              { label: "פונדמנטל", value: stock.fundamental, color: "#34D399" },
              { label: "טכני", value: stock.technical, color: "#F59E0B" },
            ].map(({ label, value, color }) => (
              <div key={label} style={{ background: "#080B12", borderRadius: 8, padding: 12, border: `1px solid ${color}20` }}>
                <div style={{ color, fontSize: 9, letterSpacing: 2, textTransform: "uppercase", marginBottom: 5 }}>{label}</div>
                <div style={{ color: "#9CA3AF", fontSize: 11, lineHeight: 1.6 }}>{value || "—"}</div>
              </div>
            ))}
          </div>
          {/* Price row */}
          <div style={{ display: "flex", gap: 20, marginTop: 10, flexWrap: "wrap" }}>
            {[
              ["מחיר נוכחי", `$${stock.currentPrice}`, "#D1D5DB"],
              ["יעד", stock.targetPrice ? `$${stock.targetPrice}` : "—", "#10B981"],
              ["תחזית אנליסטים", stock.analystTarget ? `$${stock.analystTarget}` : "—", "#34D399"],
              ["P/E", stock.pe ? `${stock.pe}x` : "—", "#818CF8"],
              ["דוח הבא", stock.earningsDate || "—", urgentEarnings ? "#F59E0B" : "#6B7280"],
            ].map(([k, v, c]) => (
              <div key={k} style={{ fontSize: 11, color: "#6B7280" }}>
                {k}: <span style={{ color: c, fontFamily: "monospace" }}>{v}</span>
              </div>
            ))}
          </div>
          {/* Portfolio positions for this stock */}
          {portfolioData && portfolioData.length > 0 && (
            <div style={{ marginTop: 12, borderTop: "1px solid #1F2937", paddingTop: 10 }}>
              <div style={{ color: "#4B5563", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 8 }}>פוזיציות חברי הצוות</div>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                {portfolioData.map(pos => {
                  const m = MEMBERS.find(x => x.id === pos.member);
                  if (!m) return null;
                  return (
                    <div key={pos.member} style={{ background: `${m.color}10`, border: `1px solid ${m.color}30`, borderRadius: 8, padding: "8px 12px", fontSize: 11 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                        <MemberAvatar member={m} size={20} />
                        <span style={{ color: m.color, fontWeight: 600 }}>{m.name}</span>
                        <span style={{ color: "#D1D5DB", fontFamily: "monospace" }}>{pos.allocation}%</span>
                      </div>
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        {pos.entry && <span style={{ color: "#6B7280" }}>כניסה: <span style={{ color: "#D1D5DB" }}>${pos.entry}</span></span>}
                        {pos.stop && <span style={{ color: "#6B7280" }}>Stop: <span style={{ color: "#EF4444" }}>${pos.stop}</span></span>}
                        {pos.target && <span style={{ color: "#6B7280" }}>TP: <span style={{ color: "#10B981" }}>${pos.target}</span></span>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// PORTFOLIO TAB
// ─────────────────────────────────────────────
function PortfolioTab({ stocks, portfolio, setPortfolio, savePortfolio }) {
  const [activeMember, setActiveMember] = useState("eyal");
  const [editStock, setEditStock] = useState(null);
  const [form, setForm] = useState({ allocation: "", entry: "", stop: "", target: "", notes: "" });

  const memberPortfolio = portfolio[activeMember] || {};
  const totalAlloc = Object.values(memberPortfolio).reduce((s, p) => s + (parseFloat(p.allocation) || 0), 0);

  const openEdit = (ticker) => {
    setEditStock(ticker);
    setForm(memberPortfolio[ticker] || { allocation: "", entry: "", stop: "", target: "", notes: "" });
  };

  const savePos = () => {
    const updated = { ...portfolio, [activeMember]: { ...memberPortfolio, [editStock]: form } };
    setPortfolio(updated);
    savePortfolio(updated);
    setEditStock(null);
  };

  const removePos = (ticker) => {
    const m = { ...memberPortfolio };
    delete m[ticker];
    const updated = { ...portfolio, [activeMember]: m };
    setPortfolio(updated);
    savePortfolio(updated);
  };

  const inp = { background: "#080B12", border: "1px solid #1F2937", borderRadius: 6, color: "#F9FAFB", padding: "7px 10px", fontSize: 12, fontFamily: "inherit", outline: "none", width: "100%", boxSizing: "border-box" };

  return (
    <div style={{ direction: "rtl" }}>
      {/* Member selector */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {MEMBERS.map(m => (
          <button key={m.id} onClick={() => setActiveMember(m.id)} style={{
            background: activeMember === m.id ? `${m.color}20` : "none",
            border: `1.5px solid ${activeMember === m.id ? m.color : "#1F2937"}`,
            color: activeMember === m.id ? m.color : "#6B7280",
            borderRadius: 10, padding: "8px 20px", cursor: "pointer", fontSize: 13, fontWeight: 600
          }}>
            <MemberAvatar member={m} size={22} /> <span style={{ marginRight: 8 }}>{m.name}</span>
          </button>
        ))}
        <div style={{ marginRight: "auto", display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ color: "#4B5563", fontSize: 12 }}>סה"כ חשיפה:</span>
          <span style={{ color: totalAlloc > 100 ? "#EF4444" : "#10B981", fontFamily: "monospace", fontWeight: 700 }}>{totalAlloc.toFixed(1)}%</span>
          {totalAlloc > 100 && <span style={{ color: "#EF4444", fontSize: 11 }}>⚠️ חריגה</span>}
        </div>
      </div>

      {/* Position list */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 10 }}>
        {stocks.map(s => {
          const pos = memberPortfolio[s.ticker];
          const sector = SECTORS[s.sector] || { color: "#6B7280", icon: "📊", label: s.sector };
          const upside = s.targetPrice && pos?.entry ? (((s.targetPrice - pos.entry) / pos.entry) * 100).toFixed(1) : null;
          const rr = pos?.entry && pos?.stop && pos?.target
            ? ((pos.target - pos.entry) / (pos.entry - pos.stop)).toFixed(1)
            : null;
          return (
            <div key={s.id} style={{ background: pos ? `${sector.color}08` : "#080B12", border: `1px solid ${pos ? sector.color + "40" : "#1F2937"}`, borderRadius: 10, padding: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontFamily: "'Space Mono', monospace", color: "#F9FAFB", fontWeight: 700 }}>{s.ticker}</span>
                    <Badge label={LAYER_CONFIG[s.layer]?.label} color={LAYER_CONFIG[s.layer]?.color} />
                  </div>
                  <div style={{ color: "#6B7280", fontSize: 11, marginTop: 2 }}>{sector.icon} {sector.label}</div>
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button onClick={() => openEdit(s.ticker)} style={{ background: "#1F2937", border: "none", color: "#9CA3AF", borderRadius: 5, padding: "4px 8px", cursor: "pointer", fontSize: 11 }}>
                    {pos ? "✏️" : "+ הוסף"}
                  </button>
                  {pos && <button onClick={() => removePos(s.ticker)} style={{ background: "none", border: "none", color: "#374151", cursor: "pointer", fontSize: 13 }}
                    onMouseEnter={e => e.target.style.color = "#EF4444"} onMouseLeave={e => e.target.style.color = "#374151"}>✕</button>}
                </div>
              </div>
              {pos ? (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, fontSize: 11 }}>
                  {[["🔵 אחזקה", `${pos.allocation}%`], ["📥 כניסה", pos.entry ? `$${pos.entry}` : "—"], ["🔴 Stop", pos.stop ? `$${pos.stop}` : "—"], ["🎯 TP", pos.target ? `$${pos.target}` : "—"]].map(([k, v]) => (
                    <div key={k} style={{ background: "#0A0D14", borderRadius: 5, padding: "5px 8px" }}>
                      <span style={{ color: "#4B5563" }}>{k}: </span>
                      <span style={{ color: "#D1D5DB", fontFamily: "monospace" }}>{v}</span>
                    </div>
                  ))}
                  {rr && (
                    <div style={{ background: parseFloat(rr) >= 2 ? "#10B98115" : "#EF444415", borderRadius: 5, padding: "5px 8px", gridColumn: "span 2" }}>
                      <span style={{ color: "#4B5563" }}>R:R </span>
                      <span style={{ color: parseFloat(rr) >= 2 ? "#10B981" : "#EF4444", fontFamily: "monospace", fontWeight: 700 }}>{rr}:1</span>
                      {upside && <span style={{ color: "#6B7280", marginRight: 10 }}>• אפסייד: <span style={{ color: "#10B981" }}>{upside}%</span></span>}
                    </div>
                  )}
                  {pos.notes && <div style={{ color: "#6B7280", fontSize: 10, gridColumn: "span 2", marginTop: 2 }}>{pos.notes}</div>}
                </div>
              ) : (
                <div style={{ color: "#2D3748", fontSize: 11, textAlign: "center", padding: "8px 0" }}>אין פוזיציה</div>
              )}
            </div>
          );
        })}
      </div>

      {/* Edit modal */}
      {editStock && (
        <div style={{ position: "fixed", inset: 0, background: "#00000090", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ background: "#0F1117", border: "1px solid #1F2937", borderRadius: 14, padding: 28, width: 360, direction: "rtl" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 18 }}>
              <h3 style={{ margin: 0, color: "#F9FAFB", fontSize: 16 }}>פוזיציה — {editStock}</h3>
              <button onClick={() => setEditStock(null)} style={{ background: "none", border: "none", color: "#6B7280", cursor: "pointer", fontSize: 18 }}>✕</button>
            </div>
            {[["allocation", "% אחזקה בתיק"], ["entry", "מחיר כניסה ($)"], ["stop", "Stop Loss ($)"], ["target", "Take Profit ($)"], ["notes", "הערות"]].map(([k, label]) => (
              <div key={k} style={{ marginBottom: 10 }}>
                <label style={{ color: "#6B7280", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", display: "block", marginBottom: 4 }}>{label}</label>
                <input style={inp} value={form[k] || ""} onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))} placeholder={k === "notes" ? "הערות חופשיות..." : ""} />
              </div>
            ))}
            <button onClick={savePos} style={{ background: "linear-gradient(135deg, #6366F1, #818CF8)", border: "none", color: "white", borderRadius: 8, padding: "10px 20px", cursor: "pointer", width: "100%", fontWeight: 600, marginTop: 6 }}>שמור</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// TRADES TAB
// ─────────────────────────────────────────────
function TradesTab({ stocks, trades, setTrades, saveTrades }) {
  const [tab, setTab] = useState("suggestions");
  const [showNew, setShowNew] = useState(false);
  const [chatTrade, setChatTrade] = useState(null);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [form, setForm] = useState({ ticker: "", entry: "", stop: "", target: "", timeframe: "", rationale: "", chartUrl: "" });
  const inp = { background: "#080B12", border: "1px solid #1F2937", borderRadius: 6, color: "#F9FAFB", padding: "7px 10px", fontSize: 12, fontFamily: "inherit", outline: "none", width: "100%", boxSizing: "border-box" };

  const suggestions = trades.filter(t => t.status === "suggestion");
  const approved = trades.filter(t => t.status === "approved");
  const newBadge = suggestions.length;

  const addTrade = () => {
    if (!form.ticker) return;
    const stock = stocks.find(s => s.ticker === form.ticker.toUpperCase());
    const t = { id: Date.now(), ...form, ticker: form.ticker.toUpperCase(), status: "suggestion", createdAt: new Date().toISOString(), stockName: stock?.name || form.ticker, chartUrl: form.chartUrl || null };
    const updated = [...trades, t];
    setTrades(updated);
    saveTrades(updated);
    setShowNew(false);
    setForm({ ticker: "", entry: "", stop: "", target: "", timeframe: "", rationale: "" });
    setTab("suggestions");
  };

  const approve = (id) => {
    const updated = trades.map(t => t.id === id ? { ...t, status: "approved", approvedAt: new Date().toISOString() } : t);
    setTrades(updated);
    saveTrades(updated);
  };

  const remove = (id) => {
    const updated = trades.filter(t => t.id !== id);
    setTrades(updated);
    saveTrades(updated);
  };

  const openChat = (trade) => {
    setChatTrade(trade);
    setChatMessages([{
      role: "assistant",
      text: `היי! אני כאן לעזור לך לעבוד על הסט-אפ של ${trade.ticker}. הכניסה המוצעת היא $${trade.entry || "—"}, Stop $${trade.stop || "—"}, יעד $${trade.target || "—"}. מה רוצה לשנות או לבדוק?`
    }]);
  };

  const sendChat = async () => {
    if (!chatInput.trim() || chatLoading) return;
    const userMsg = chatInput.trim();
    setChatInput("");
    setChatMessages(prev => [...prev, { role: "user", text: userMsg }]);
    setChatLoading(true);
    try {
      const context = `אתה עוזר למשקיעים לנתח ולשפר סט-אפים של טריידים. הטרייד הנוכחי: טיקר: \${chatTrade.ticker}, כניסה: $\${chatTrade.entry}, Stop Loss: $\${chatTrade.stop}, יעד: $\${chatTrade.target}, טווח זמן: \${chatTrade.timeframe || "לא הוגדר"}, רציונל: \${chatTrade.rationale || "לא הוגדר"}. ענה בעברית, בצורה תמציתית ומקצועית. אם המשתמש רוצה לשנות פרמטר — תן המלצה ברורה עם מספרים.`;
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: context,
          messages: [
            ...chatMessages.filter(m => m.role !== "assistant" || chatMessages.indexOf(m) > 0).map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.text })),
            { role: "user", content: userMsg }
          ]
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "שגיאה בתגובה";
      setChatMessages(prev => [...prev, { role: "assistant", text: reply }]);
    } catch (e) {
      setChatMessages(prev => [...prev, { role: "assistant", text: "שגיאה בחיבור לClaude. נסה שוב." }]);
    }
    setChatLoading(false);
  };

  const applyFromChat = (field, value) => {
    if (!chatTrade) return;
    const updated = trades.map(t => t.id === chatTrade.id ? { ...t, [field]: value } : t);
    setTrades(updated);
    saveTrades(updated);
    setChatTrade(prev => ({ ...prev, [field]: value }));
    setChatMessages(prev => [...prev, { role: "assistant", text: `✅ עדכנתי את \${field} ל-\${value}` }]);
  };

  const TradeCard = ({ trade }) => {
    const rr = trade.entry && trade.stop && trade.target
      ? ((trade.target - trade.entry) / (trade.entry - trade.stop)).toFixed(1)
      : null;
    const upside = trade.entry && trade.target ? (((trade.target - trade.entry) / trade.entry) * 100).toFixed(1) : null;
    const sector = stocks.find(s => s.ticker === trade.ticker);
    const sc = sector ? SECTORS[sector.sector] : null;

    return (
      <div style={{ background: "#0A0D14", border: `1px solid ${trade.status === "approved" ? "#10B98140" : "#1F2937"}`, borderRadius: 12, padding: 16, position: "relative" }}>
        {trade.status === "approved" && <div style={{ position: "absolute", top: 10, left: 10, background: "#10B98120", color: "#10B981", borderRadius: 5, padding: "2px 8px", fontSize: 10 }}>✅ מאושר</div>}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
          <div>
            <div style={{ fontFamily: "'Space Mono', monospace", color: "#F9FAFB", fontWeight: 700, fontSize: 16 }}>{trade.ticker}</div>
            <div style={{ color: sc?.color || "#6B7280", fontSize: 11, marginTop: 2 }}>{sc?.icon} {trade.stockName}</div>
          </div>
          <div style={{ color: "#4B5563", fontSize: 10 }}>{new Date(trade.createdAt).toLocaleDateString("he-IL")}</div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginBottom: 12 }}>
          {[["📥 כניסה", trade.entry ? `$${trade.entry}` : "—", "#D1D5DB"], ["🔴 Stop", trade.stop ? `$${trade.stop}` : "—", "#EF4444"], ["🎯 יעד", trade.target ? `$${trade.target}` : "—", "#10B981"]].map(([k, v, c]) => (
            <div key={k} style={{ background: "#080B12", borderRadius: 7, padding: "8px 10px", textAlign: "center" }}>
              <div style={{ color: "#4B5563", fontSize: 10 }}>{k}</div>
              <div style={{ color: c, fontFamily: "monospace", fontWeight: 700, marginTop: 2 }}>{v}</div>
            </div>
          ))}
        </div>
        {(rr || trade.timeframe) && (
          <div style={{ display: "flex", gap: 12, marginBottom: 10, fontSize: 11 }}>
            {rr && <span style={{ color: parseFloat(rr) >= 2 ? "#10B981" : "#EF4444" }}>R:R {rr}:1</span>}
            {upside && <span style={{ color: "#6B7280" }}>אפסייד: <span style={{ color: "#10B981" }}>{upside}%</span></span>}
            {trade.timeframe && <span style={{ color: "#6B7280" }}>⏱ {trade.timeframe}</span>}
          </div>
        )}
        {trade.rationale && (
          <div style={{ background: "#080B12", borderRadius: 7, padding: 10, color: "#9CA3AF", fontSize: 11, lineHeight: 1.6, marginBottom: 12 }}>
            💡 {trade.rationale}
          </div>
        )}
        {trade.chartUrl && (
          <div style={{ marginBottom: 12 }}>
            <div style={{ color: "#4B5563", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 6 }}>📈 גרף</div>
            <div style={{ borderRadius: 8, overflow: "hidden", border: "1px solid #1F2937", cursor: "pointer" }} onClick={() => window.open(trade.chartUrl, "_blank")}>
              <img src={trade.chartUrl} alt="גרף" style={{ width: "100%", maxHeight: 220, objectFit: "cover", display: "block" }}
                onError={e => { e.target.style.display = "none"; e.target.nextSibling.style.display = "flex"; }} />
              <div style={{ display: "none", padding: "10px", color: "#EF4444", fontSize: 11, justifyContent: "center" }}>❌ לא ניתן לטעון את הגרף — לחץ לפתיחה</div>
            </div>
          </div>
        )}
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", flexWrap: "wrap" }}>
          <button onClick={() => openChat(trade)} style={{ background: "#1F2937", border: "1px solid #374151", color: "#9CA3AF", borderRadius: 7, padding: "7px 14px", cursor: "pointer", fontSize: 12 }}>
            💬 שיחה עם Claude
          </button>
          {trade.status === "suggestion" && (
            <button onClick={() => approve(trade.id)} style={{ background: "linear-gradient(135deg, #10B981, #059669)", border: "none", color: "white", borderRadius: 7, padding: "7px 14px", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>
              ✅ אישור טרייד
            </button>
          )}
          <button onClick={() => remove(trade.id)} style={{ background: "none", border: "1px solid #1F2937", color: "#6B7280", borderRadius: 7, padding: "7px 14px", cursor: "pointer", fontSize: 12 }}>
            הסרה
          </button>
        </div>
      </div>
    );
  };

  return (
    <div style={{ direction: "rtl" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ display: "flex", gap: 8 }}>
          {[["suggestions", "הצעות", newBadge], ["approved", "מאושרים", 0]].map(([id, label, badge]) => (
            <button key={id} onClick={() => setTab(id)} style={{
              background: tab === id ? "#1F2937" : "none",
              border: `1px solid ${tab === id ? "#374151" : "#1F2937"}`,
              color: tab === id ? "#F9FAFB" : "#6B7280",
              borderRadius: 8, padding: "7px 16px", cursor: "pointer", fontSize: 13, position: "relative"
            }}>
              {label}
              {badge > 0 && <span style={{ position: "absolute", top: -5, right: -5, background: "#EF4444", color: "white", borderRadius: "50%", width: 16, height: 16, fontSize: 9, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 }}>{badge}</span>}
            </button>
          ))}
        </div>
        <button onClick={() => setShowNew(true)} style={{ background: "linear-gradient(135deg, #6366F1, #818CF8)", border: "none", color: "white", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
          + הצעת טרייד חדשה
        </button>
      </div>

      {tab === "suggestions" && (
        suggestions.length === 0
          ? <div style={{ textAlign: "center", padding: "60px 0", color: "#374151" }}>אין הצעות טריידים כרגע</div>
          : <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
              {suggestions.map(t => <TradeCard key={t.id} trade={t} />)}
            </div>
      )}

      {tab === "approved" && (
        approved.length === 0
          ? <div style={{ textAlign: "center", padding: "60px 0", color: "#374151" }}>אין טריידים מאושרים עדיין</div>
          : <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
              {approved.map(t => <TradeCard key={t.id} trade={t} />)}
            </div>
      )}

      {/* Claude Chat Modal */}
      {chatTrade && (
        <div style={{ position: "fixed", inset: 0, background: "#00000090", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#0F1117", border: "1px solid #6366F140", borderRadius: 16, padding: 0, width: "100%", maxWidth: 520, direction: "rtl", overflow: "hidden", display: "flex", flexDirection: "column", maxHeight: "80vh" }}>
            {/* Header */}
            <div style={{ padding: "16px 20px", borderBottom: "1px solid #1F2937", display: "flex", justifyContent: "space-between", alignItems: "center", background: "#080B12" }}>
              <div>
                <div style={{ color: "#F9FAFB", fontWeight: 700, fontFamily: "monospace" }}>💬 התייעצות — {chatTrade.ticker}</div>
                <div style={{ color: "#4B5563", fontSize: 11, marginTop: 2 }}>
                  כניסה: <span style={{ color: "#D1D5DB" }}>${chatTrade.entry}</span> ·
                  Stop: <span style={{ color: "#EF4444" }}>${chatTrade.stop}</span> ·
                  יעד: <span style={{ color: "#10B981" }}>${chatTrade.target}</span>
                </div>
              </div>
              <button onClick={() => setChatTrade(null)} style={{ background: "none", border: "none", color: "#6B7280", cursor: "pointer", fontSize: 20 }}>✕</button>
            </div>
            {/* Quick actions */}
            <div style={{ padding: "10px 16px", borderBottom: "1px solid #1F2937", display: "flex", gap: 6, flexWrap: "wrap" }}>
              {["מה יחס R:R?", "האם הסטופ מתאים לATR?", "האם הכניסה אופטימלית?", "הצע יעד שני"].map(q => (
                <button key={q} onClick={() => { setChatInput(q); }} style={{ background: "#1F2937", border: "none", color: "#9CA3AF", borderRadius: 15, padding: "4px 10px", cursor: "pointer", fontSize: 11 }}>{q}</button>
              ))}
            </div>
            {/* Messages */}
            <div style={{ flex: 1, overflowY: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 10 }}>
              {chatMessages.map((m, i) => (
                <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-start" : "flex-end" }}>
                  <div style={{
                    background: m.role === "user" ? "#1F2937" : "#6366F120",
                    border: m.role === "user" ? "none" : "1px solid #6366F140",
                    borderRadius: m.role === "user" ? "12px 12px 4px 12px" : "12px 12px 12px 4px",
                    padding: "10px 14px", maxWidth: "85%", color: "#D1D5DB", fontSize: 13, lineHeight: 1.6
                  }}>{m.text}</div>
                </div>
              ))}
              {chatLoading && (
                <div style={{ display: "flex", justifyContent: "flex-end" }}>
                  <div style={{ background: "#6366F120", border: "1px solid #6366F140", borderRadius: "12px 12px 12px 4px", padding: "10px 14px", color: "#6366F1", fontSize: 12 }}>מחשב...</div>
                </div>
              )}
            </div>
            {/* Input */}
            <div style={{ padding: "12px 16px", borderTop: "1px solid #1F2937", display: "flex", gap: 8 }}>
              <input
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && sendChat()}
                placeholder="שאל על הסט-אפ, בקש שינוי, קבל ניתוח..."
                style={{ flex: 1, background: "#080B12", border: "1px solid #1F2937", borderRadius: 8, color: "#F9FAFB", padding: "9px 12px", fontSize: 13, fontFamily: "inherit", outline: "none" }}
              />
              <button onClick={sendChat} disabled={chatLoading} style={{ background: "linear-gradient(135deg, #6366F1, #818CF8)", border: "none", color: "white", borderRadius: 8, padding: "9px 16px", cursor: "pointer", fontSize: 13 }}>שלח</button>
            </div>
          </div>
        </div>
      )}

      {/* New trade modal */}
      {showNew && (
        <div style={{ position: "fixed", inset: 0, background: "#00000090", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#0F1117", border: "1px solid #1F2937", borderRadius: 14, padding: 28, width: "100%", maxWidth: 420, direction: "rtl" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 18 }}>
              <h3 style={{ margin: 0, color: "#F9FAFB" }}>הצעת טרייד חדשה</h3>
              <button onClick={() => setShowNew(false)} style={{ background: "none", border: "none", color: "#6B7280", cursor: "pointer", fontSize: 18 }}>✕</button>
            </div>
            {[["ticker", "טיקר *"], ["entry", "כניסה ($)"], ["stop", "Stop Loss ($)"], ["target", "יעד / Take Profit ($)"], ["timeframe", "טווח זמן (לדוגמה: 2-4 שבועות)"]].map(([k, label]) => (
              <div key={k} style={{ marginBottom: 10 }}>
                <label style={{ color: "#6B7280", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", display: "block", marginBottom: 4 }}>{label}</label>
                <input style={inp} value={form[k] || ""} onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))} />
              </div>
            ))}
            <div style={{ marginBottom: 14 }}>
              <label style={{ color: "#6B7280", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", display: "block", marginBottom: 4 }}>רציונל ופירוט</label>
              <textarea style={{ ...inp, minHeight: 80, resize: "vertical" }} value={form.rationale || ""} onChange={e => setForm(f => ({ ...f, rationale: e.target.value }))} placeholder="למה הטרייד הזה? מה הקטליסט? איך למקם?" />
            </div>
            <div style={{ marginBottom: 14 }}>
              {label("קישור לגרף (אופציונלי)")}
              <input style={inp} value={form.chartUrl || ""} onChange={e => setForm(f => ({ ...f, chartUrl: e.target.value }))} placeholder="הדבק קישור לגרף מ-TradingView, Google Photos וכו'..." />
              {form.chartUrl && (
                <div style={{ marginTop: 8, borderRadius: 8, overflow: "hidden", border: "1px solid #1F2937", maxHeight: 200 }}>
                  <img src={form.chartUrl} alt="גרף" style={{ width: "100%", objectFit: "cover" }} onError={e => e.target.style.display = "none"} />
                </div>
              )}
            </div>
            <button onClick={addTrade} style={{ background: "linear-gradient(135deg, #6366F1, #818CF8)", border: "none", color: "white", borderRadius: 8, padding: "10px", cursor: "pointer", width: "100%", fontWeight: 600 }}>הוסף הצעה</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// STAT CARD
// ─────────────────────────────────────────────
function StatCard({ label, value, sub, color }) {
  return (
    <div style={{ background: "#0A0D14", border: `1px solid ${color}25`, borderRadius: 10, padding: "16px 18px", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${color}, transparent)` }} />
      <div style={{ color: "#4B5563", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>{label}</div>
      <div style={{ color: "#F9FAFB", fontSize: 24, fontWeight: 700, fontFamily: "'Space Mono', monospace" }}>{value}</div>
      {sub && <div style={{ color: color, fontSize: 11, marginTop: 3 }}>{sub}</div>}
    </div>
  );
}

// ─────────────────────────────────────────────
// 1. RISK HEATMAP TAB
// ─────────────────────────────────────────────
function RiskHeatmapTab({ stocks }) {
  const total = stocks.length;
  const byRisk = {
    high:   stocks.filter(s => s.risk === "high"),
    medium: stocks.filter(s => s.risk === "medium"),
    low:    stocks.filter(s => s.risk === "low"),
  };
  const bySector = Object.keys(SECTORS).map(sk => ({
    key: sk,
    sector: SECTORS[sk],
    high:   stocks.filter(s => s.sector === sk && s.risk === "high"),
    medium: stocks.filter(s => s.sector === sk && s.risk === "medium"),
    low:    stocks.filter(s => s.sector === sk && s.risk === "low"),
    total:  stocks.filter(s => s.sector === sk),
  })).filter(s => s.total.length > 0);

  const byLayer = Object.entries(LAYER_CONFIG).map(([k, v]) => ({
    key: k, config: v,
    high:   stocks.filter(s => s.layer === k && s.risk === "high"),
    medium: stocks.filter(s => s.layer === k && s.risk === "medium"),
    low:    stocks.filter(s => s.layer === k && s.risk === "low"),
    total:  stocks.filter(s => s.layer === k),
  })).filter(s => s.total.length > 0);

  const RiskBar = ({ high, medium, low, total }) => {
    const hw = total.length ? (high.length / total.length) * 100 : 0;
    const mw = total.length ? (medium.length / total.length) * 100 : 0;
    const lw = total.length ? (low.length / total.length) * 100 : 0;
    return (
      <div style={{ height: 8, borderRadius: 4, overflow: "hidden", display: "flex", background: "#1F2937" }}>
        {hw > 0 && <div style={{ width: `${hw}%`, background: "#EF4444", transition: "width 0.5s" }} />}
        {mw > 0 && <div style={{ width: `${mw}%`, background: "#F59E0B", transition: "width 0.5s" }} />}
        {lw > 0 && <div style={{ width: `${lw}%`, background: "#10B981", transition: "width 0.5s" }} />}
      </div>
    );
  };

  const RiskPill = ({ count, color, label }) => count > 0 ? (
    <span style={{ background: `${color}20`, color, borderRadius: 5, padding: "2px 7px", fontSize: 10, marginLeft: 4 }}>{count} {label}</span>
  ) : null;

  return (
    <div style={{ direction: "rtl" }}>
      {/* Overview donut-style */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginBottom: 24 }}>
        {[
          { risk: "high", label: "סיכון גבוה", color: "#EF4444", stocks: byRisk.high },
          { risk: "medium", label: "סיכון בינוני", color: "#F59E0B", stocks: byRisk.medium },
          { risk: "low", label: "סיכון נמוך", color: "#10B981", stocks: byRisk.low },
        ].map(({ risk, label, color, stocks: rs }) => (
          <div key={risk} style={{ background: `${color}08`, border: `1px solid ${color}30`, borderRadius: 12, padding: 18, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: 0, right: 0, width: 60, height: 60, borderRadius: "0 0 0 60px", background: `${color}15` }} />
            <div style={{ color: "#6B7280", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>{label}</div>
            <div style={{ fontSize: 36, fontWeight: 700, fontFamily: "'Space Mono', monospace", color }}>{rs.length}</div>
            <div style={{ color: "#4B5563", fontSize: 11, marginTop: 4 }}>{total ? ((rs.length / total) * 100).toFixed(0) : 0}% מהבנק</div>
            <div style={{ marginTop: 10, display: "flex", flexWrap: "wrap", gap: 4 }}>
              {rs.slice(0, 5).map(s => (
                <span key={s.id} style={{ background: "#080B12", border: `1px solid ${color}30`, color: "#9CA3AF", borderRadius: 4, padding: "1px 6px", fontSize: 10, fontFamily: "monospace" }}>{s.ticker}</span>
              ))}
              {rs.length > 5 && <span style={{ color: "#4B5563", fontSize: 10 }}>+{rs.length - 5}</span>}
            </div>
          </div>
        ))}
      </div>

      {/* Overall bar */}
      <div style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 12, padding: 18, marginBottom: 20 }}>
        <div style={{ color: "#6B7280", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>חלוקת סיכון כוללת — {total} מניות</div>
        <RiskBar high={byRisk.high} medium={byRisk.medium} low={byRisk.low} total={stocks} />
        <div style={{ display: "flex", gap: 16, marginTop: 10, fontSize: 11 }}>
          {[["#EF4444", "גבוה", byRisk.high.length], ["#F59E0B", "בינוני", byRisk.medium.length], ["#10B981", "נמוך", byRisk.low.length]].map(([c, l, n]) => (
            <div key={l} style={{ display: "flex", alignItems: "center", gap: 5 }}>
              <div style={{ width: 8, height: 8, borderRadius: 2, background: c }} />
              <span style={{ color: "#6B7280" }}>{l}:</span>
              <span style={{ color: c, fontFamily: "monospace", fontWeight: 700 }}>{n}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* By Sector */}
        <div style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 12, padding: 18 }}>
          <div style={{ color: "#6B7280", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>לפי סקטור</div>
          {bySector.map(s => (
            <div key={s.key} style={{ marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <span>{s.sector.icon}</span>
                  <span style={{ color: s.sector.color, fontSize: 12, fontWeight: 600 }}>{s.sector.label}</span>
                </div>
                <div style={{ fontSize: 10 }}>
                  <RiskPill count={s.high.length} color="#EF4444" label="↑" />
                  <RiskPill count={s.medium.length} color="#F59E0B" label="~" />
                  <RiskPill count={s.low.length} color="#10B981" label="↓" />
                </div>
              </div>
              <RiskBar high={s.high} medium={s.medium} low={s.low} total={s.total} />
            </div>
          ))}
        </div>

        {/* By Layer */}
        <div style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 12, padding: 18 }}>
          <div style={{ color: "#6B7280", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", marginBottom: 14 }}>לפי שכבה</div>
          {byLayer.map(l => (
            <div key={l.key} style={{ marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: l.config.color }} />
                  <span style={{ color: l.config.color, fontSize: 12, fontWeight: 600 }}>{l.config.label}</span>
                  <span style={{ color: "#4B5563", fontSize: 10 }}>({l.total.length})</span>
                </div>
                <div style={{ fontSize: 10 }}>
                  <RiskPill count={l.high.length} color="#EF4444" label="" />
                  <RiskPill count={l.medium.length} color="#F59E0B" label="" />
                  <RiskPill count={l.low.length} color="#10B981" label="" />
                </div>
              </div>
              <RiskBar high={l.high} medium={l.medium} low={l.low} total={l.total} />
              {l.key === "core" && l.high.length > 0 && (
                <div style={{ color: "#EF4444", fontSize: 10, marginTop: 4 }}>
                  ⚠️ {l.high.length} מניות סיכון גבוה בשכבת ליבה — בדוק עקביות
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* High risk stocks detail */}
      {byRisk.high.length > 0 && (
        <div style={{ background: "#EF444408", border: "1px solid #EF444430", borderRadius: 12, padding: 18, marginTop: 16 }}>
          <div style={{ color: "#EF4444", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>⚠️ מניות סיכון גבוה — {byRisk.high.length} מניות</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 8 }}>
            {byRisk.high.map(s => {
              const sector = SECTORS[s.sector];
              return (
                <div key={s.id} style={{ background: "#080B12", borderRadius: 8, padding: "8px 12px", border: "1px solid #EF444420" }}>
                  <div style={{ fontFamily: "monospace", color: "#F9FAFB", fontWeight: 700, fontSize: 13 }}>{s.ticker}</div>
                  <div style={{ color: sector?.color || "#6B7280", fontSize: 10, marginTop: 2 }}>{sector?.icon} {sector?.label}</div>
                  <div style={{ color: "#4B5563", fontSize: 10, marginTop: 2 }}>{LAYER_CONFIG[s.layer]?.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// 2. RR CALCULATOR TAB
// ─────────────────────────────────────────────
function RRCalcTab({ stocks }) {
  const [ticker, setTicker] = useState("");
  const [entry, setEntry] = useState("");
  const [stop, setStop] = useState("");
  const [target, setTarget] = useState("");
  const [target2, setTarget2] = useState("");
  const [portfolioSize, setPortfolioSize] = useState("100000");
  const [riskPct, setRiskPct] = useState("1");
  const [result, setResult] = useState(null);

  const selectedStock = stocks.find(s => s.ticker === ticker.toUpperCase());

  const calculate = () => {
    const e = parseFloat(entry), s = parseFloat(stop), t = parseFloat(target);
    if (!e || !s || !t) return;
    const risk = e - s;
    const reward = t - e;
    const rr = reward / risk;
    const portfolioDollar = parseFloat(portfolioSize) * (parseFloat(riskPct) / 100);
    const shares = Math.floor(portfolioDollar / Math.abs(risk));
    const maxLoss = shares * Math.abs(risk);
    const maxGain = shares * reward;
    const upside = ((t - e) / e) * 100;
    const downside = ((s - e) / e) * 100;
    const t2 = parseFloat(target2);
    setResult({ rr, shares, maxLoss, maxGain, upside, downside, risk, reward, t2: t2 || null, gain2: t2 ? shares * (t2 - e) : null });
  };

  const inp = { background: "#080B12", border: "1px solid #1F2937", borderRadius: 7, color: "#F9FAFB", padding: "9px 12px", fontSize: 13, fontFamily: "inherit", outline: "none", width: "100%", boxSizing: "border-box" };
  const label = (text) => <div style={{ color: "#6B7280", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 5 }}>{text}</div>;

  const autofill = (s) => {
    setTicker(s.ticker);
    if (s.currentPrice) setEntry(String(s.currentPrice));
    if (s.targetPrice) setTarget(String(s.targetPrice));
  };

  return (
    <div style={{ direction: "rtl" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Input panel */}
        <div style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 14, padding: 22 }}>
          <div style={{ color: "#F9FAFB", fontWeight: 600, marginBottom: 18, fontSize: 15 }}>🧮 מחשבון R:R וגודל פוזיציה</div>

          {/* Stock selector */}
          <div style={{ marginBottom: 14 }}>
            {label("בחר מנייה מהבנק (אופציונלי)")}
            <select value={ticker} onChange={e => { setTicker(e.target.value); const s = stocks.find(x => x.ticker === e.target.value); if (s) autofill(s); }} style={{ ...inp }}>
              <option value="">— בחר מנייה —</option>
              {stocks.map(s => <option key={s.id} value={s.ticker}>{s.ticker} — {s.name}</option>)}
            </select>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
            <div>{label("כניסה ($)")} <input style={inp} type="number" value={entry} onChange={e => setEntry(e.target.value)} placeholder="100.00" /></div>
            <div>{label("Stop Loss ($)")} <input style={inp} type="number" value={stop} onChange={e => setStop(e.target.value)} placeholder="92.00" /></div>
            <div>{label("יעד 1 ($)")} <input style={inp} type="number" value={target} onChange={e => setTarget(e.target.value)} placeholder="120.00" /></div>
            <div>{label("יעד 2 ($) — אופציונלי")} <input style={inp} type="number" value={target2} onChange={e => setTarget2(e.target.value)} placeholder="135.00" /></div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
            <div>{label("גודל תיק ($)")} <input style={inp} type="number" value={portfolioSize} onChange={e => setPortfolioSize(e.target.value)} placeholder="100000" /></div>
            <div>{label("סיכון מקסימלי (%)")} <input style={inp} type="number" value={riskPct} onChange={e => setRiskPct(e.target.value)} placeholder="1" /></div>
          </div>

          <button onClick={calculate} style={{ background: "linear-gradient(135deg, #6366F1, #818CF8)", border: "none", color: "white", borderRadius: 8, padding: "11px", cursor: "pointer", width: "100%", fontWeight: 700, fontSize: 14 }}>
            חשב
          </button>
        </div>

        {/* Results panel */}
        <div style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 14, padding: 22 }}>
          <div style={{ color: "#F9FAFB", fontWeight: 600, marginBottom: 18, fontSize: 15 }}>📊 תוצאות</div>
          {!result ? (
            <div style={{ color: "#374151", textAlign: "center", padding: "40px 0", fontSize: 13 }}>מלא את השדות ולחץ חשב</div>
          ) : (
            <>
              {/* R:R big display */}
              <div style={{ textAlign: "center", padding: "20px 0", marginBottom: 16, background: result.rr >= 2 ? "#10B98110" : result.rr >= 1 ? "#F59E0B10" : "#EF444410", borderRadius: 10, border: `1px solid ${result.rr >= 2 ? "#10B98140" : result.rr >= 1 ? "#F59E0B40" : "#EF444440"}` }}>
                <div style={{ color: "#6B7280", fontSize: 10, letterSpacing: 2, marginBottom: 6 }}>יחס סיכוי/סיכון</div>
                <div style={{ fontSize: 52, fontWeight: 700, fontFamily: "'Space Mono', monospace", color: result.rr >= 2 ? "#10B981" : result.rr >= 1 ? "#F59E0B" : "#EF4444", lineHeight: 1 }}>
                  {result.rr.toFixed(2)}:1
                </div>
                <div style={{ color: "#6B7280", fontSize: 11, marginTop: 8 }}>
                  {result.rr >= 3 ? "🔥 מצוין" : result.rr >= 2 ? "✅ טוב" : result.rr >= 1 ? "⚠️ בסף" : "❌ לא כדאי"}
                </div>
              </div>

              {/* Details grid */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                {[
                  ["מניות לקנות", result.shares, "#F9FAFB"],
                  ["סיכון מקסימלי", `-$${result.maxLoss.toFixed(0)}`, "#EF4444"],
                  ["רווח יעד 1", `+$${result.maxGain.toFixed(0)}`, "#10B981"],
                  result.gain2 ? ["רווח יעד 2", `+$${result.gain2.toFixed(0)}`, "#34D399"] : null,
                  ["אפסייד %", `${result.upside.toFixed(1)}%`, "#10B981"],
                  ["דאונסייד %", `${result.downside.toFixed(1)}%`, "#EF4444"],
                  ["סיכון לכניסה", `$${Math.abs(result.risk).toFixed(2)}`, "#F59E0B"],
                  ["פוטנציאל לכניסה", `$${result.reward.toFixed(2)}`, "#10B981"],
                ].filter(Boolean).map(([k, v, c]) => (
                  <div key={k} style={{ background: "#080B12", borderRadius: 8, padding: "10px 12px" }}>
                    <div style={{ color: "#4B5563", fontSize: 10, marginBottom: 3 }}>{k}</div>
                    <div style={{ color: c, fontFamily: "'Space Mono', monospace", fontWeight: 700, fontSize: 15 }}>{v}</div>
                  </div>
                ))}
              </div>

              {selectedStock && (
                <div style={{ marginTop: 12, background: "#080B12", borderRadius: 8, padding: 10, fontSize: 11, color: "#6B7280" }}>
                  📌 {selectedStock.name} · {selectedStock.thesis?.substring(0, 80)}...
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// 3. EARNINGS CALENDAR TAB
// ─────────────────────────────────────────────
function EarningsCalendarTab({ stocks }) {
  const withDates = stocks.filter(s => s.earningsDate).sort((a, b) => new Date(a.earningsDate) - new Date(b.earningsDate));
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const upcoming = withDates.filter(s => new Date(s.earningsDate) >= today);
  const past = withDates.filter(s => new Date(s.earningsDate) < today).reverse();

  // Group upcoming by week
  const weeks = {};
  upcoming.forEach(s => {
    const d = new Date(s.earningsDate);
    const weekStart = new Date(d);
    weekStart.setDate(d.getDate() - d.getDay() + 1);
    const key = weekStart.toISOString().split("T")[0];
    if (!weeks[key]) weeks[key] = [];
    weeks[key].push(s);
  });

  const EarningsCard = ({ stock, isPast }) => {
    const sector = SECTORS[stock.sector];
    const d = new Date(stock.earningsDate);
    const days = Math.ceil((d - today) / 86400000);
    const urgent = !isPast && days <= 7;
    return (
      <div style={{ background: urgent ? "#F59E0B08" : "#080B12", border: `1px solid ${urgent ? "#F59E0B40" : sector?.color + "30" || "#1F2937"}`, borderRadius: 10, padding: "12px 14px", display: "flex", alignItems: "center", gap: 12 }}>
        {/* Date bubble */}
        <div style={{ textAlign: "center", minWidth: 44, background: urgent ? "#F59E0B20" : `${sector?.color}15`, borderRadius: 8, padding: "6px 8px" }}>
          <div style={{ color: urgent ? "#F59E0B" : sector?.color || "#6B7280", fontSize: 16, fontWeight: 700, fontFamily: "monospace" }}>
            {d.getDate()}
          </div>
          <div style={{ color: "#6B7280", fontSize: 9 }}>
            {d.toLocaleString("he-IL", { month: "short" })}
          </div>
        </div>
        {/* Info */}
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontFamily: "monospace", color: "#F9FAFB", fontWeight: 700, fontSize: 14 }}>{stock.ticker}</span>
            <span style={{ color: sector?.color || "#6B7280", fontSize: 11 }}>{sector?.icon} {sector?.label}</span>
            {urgent && <span style={{ background: "#F59E0B20", color: "#F59E0B", borderRadius: 4, padding: "1px 6px", fontSize: 9 }}>⚡ {days === 0 ? "היום" : `${days}י`}</span>}
            {isPast && <span style={{ color: "#374151", fontSize: 10 }}>עבר</span>}
          </div>
          <div style={{ color: "#6B7280", fontSize: 11, marginTop: 2 }}>{stock.name}</div>
        </div>
        {/* Layer badge */}
        <div style={{ background: `${LAYER_CONFIG[stock.layer]?.color}20`, color: LAYER_CONFIG[stock.layer]?.color, borderRadius: 5, padding: "2px 8px", fontSize: 10 }}>
          {LAYER_CONFIG[stock.layer]?.label}
        </div>
      </div>
    );
  };

  return (
    <div style={{ direction: "rtl" }}>
      {/* Summary row */}
      <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
        {[
          ["📅 סה״כ עם תאריך", withDates.length, "#6366F1"],
          ["⚡ השבוע הקרוב", upcoming.filter(s => daysUntil(s.earningsDate) <= 7).length, "#F59E0B"],
          ["📆 30 יום הבאים", upcoming.filter(s => daysUntil(s.earningsDate) <= 30).length, "#34D399"],
          ["✅ עברו", past.length, "#4B5563"],
        ].map(([label, val, color]) => (
          <div key={label} style={{ background: "#0A0D14", border: `1px solid ${color}30`, borderRadius: 10, padding: "12px 18px", display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ color, fontSize: 24, fontFamily: "monospace", fontWeight: 700 }}>{val}</span>
            <span style={{ color: "#6B7280", fontSize: 12 }}>{label}</span>
          </div>
        ))}
      </div>

      {/* Upcoming by week */}
      {Object.entries(weeks).length === 0 ? (
        <div style={{ color: "#374151", textAlign: "center", padding: "40px 0" }}>אין דוחות קרובים</div>
      ) : (
        Object.entries(weeks).map(([weekKey, weekStocks]) => {
          const weekDate = new Date(weekKey);
          const weekEnd = new Date(weekDate);
          weekEnd.setDate(weekDate.getDate() + 6);
          const isThisWeek = today >= weekDate && today <= weekEnd;
          return (
            <div key={weekKey} style={{ marginBottom: 20 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                <div style={{ height: 1, flex: 1, background: "#1F2937" }} />
                <div style={{ color: isThisWeek ? "#F59E0B" : "#4B5563", fontSize: 12, fontWeight: isThisWeek ? 700 : 400, whiteSpace: "nowrap" }}>
                  {isThisWeek ? "⚡ " : ""}שבוע {weekDate.toLocaleDateString("he-IL", { day: "numeric", month: "short" })} — {weekEnd.toLocaleDateString("he-IL", { day: "numeric", month: "short" })}
                  <span style={{ color: "#374151", marginRight: 6 }}>({weekStocks.length} דוחות)</span>
                </div>
                <div style={{ height: 1, flex: 1, background: "#1F2937" }} />
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {weekStocks.map(s => <EarningsCard key={s.id} stock={s} isPast={false} />)}
              </div>
            </div>
          );
        })
      )}

      {/* Past earnings */}
      {past.length > 0 && (
        <div style={{ marginTop: 24 }}>
          <div style={{ color: "#374151", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>דוחות שעברו</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6, opacity: 0.6 }}>
            {past.slice(0, 5).map(s => <EarningsCard key={s.id} stock={s} isPast={true} />)}
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// 4. COMPARE TAB
// ─────────────────────────────────────────────
function CompareTab({ stocks }) {
  const [selected, setSelected] = useState([]);

  const toggle = (id) => {
    setSelected(prev => {
      if (prev.includes(id)) return prev.filter(x => x !== id);
      if (prev.length >= 3) return prev;
      return [...prev, id];
    });
  };

  const compared = selected.map(id => stocks.find(s => s.id === id)).filter(Boolean);

  const FIELDS = [
    { key: "currentPrice", label: "מחיר נוכחי", format: v => v ? `$${v}` : "—", compare: "none" },
    { key: "targetPrice", label: "מחיר יעד", format: v => v ? `$${v}` : "—", compare: "high" },
    { key: "analystTarget", label: "יעד אנליסטים", format: v => v ? `$${v}` : "—", compare: "high" },
    { key: "pe", label: "P/E", format: v => v ? `${v}x` : "N/A", compare: "low" },
    { key: "upside", label: "אפסייד %", format: (v, s) => s.targetPrice && s.currentPrice ? `${(((s.targetPrice - s.currentPrice) / s.currentPrice) * 100).toFixed(1)}%` : "—", compare: "high", virtual: true },
    { key: "risk", label: "סיכון", format: v => RISK_CONFIG[v]?.label || v, compare: "none" },
    { key: "layer", label: "שכבה", format: v => LAYER_CONFIG[v]?.label || v, compare: "none" },
    { key: "sector", label: "סקטור", format: v => SECTORS[v]?.label || v, compare: "none" },
  ];

  const getVal = (stock, field) => {
    if (field.virtual && field.key === "upside") {
      return stock.targetPrice && stock.currentPrice ? ((stock.targetPrice - stock.currentPrice) / stock.currentPrice) * 100 : null;
    }
    return stock[field.key];
  };

  const isBest = (field, stock) => {
    if (field.compare === "none") return false;
    const vals = compared.map(s => getVal(s, field)).filter(v => v !== null && v !== undefined);
    if (vals.length < 2) return false;
    const v = getVal(stock, field);
    return field.compare === "high" ? v === Math.max(...vals) : v === Math.min(...vals);
  };

  return (
    <div style={{ direction: "rtl" }}>
      {/* Selector */}
      <div style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 12, padding: 16, marginBottom: 20 }}>
        <div style={{ color: "#6B7280", fontSize: 10, letterSpacing: 2, textTransform: "uppercase", marginBottom: 12 }}>
          בחר עד 3 מניות להשוואה ({selected.length}/3)
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {stocks.map(s => {
            const isSelected = selected.includes(s.id);
            const sector = SECTORS[s.sector];
            return (
              <button key={s.id} onClick={() => toggle(s.id)} style={{
                background: isSelected ? `${sector?.color}20` : "#080B12",
                border: `1.5px solid ${isSelected ? sector?.color : "#1F2937"}`,
                color: isSelected ? sector?.color : "#6B7280",
                borderRadius: 7, padding: "5px 12px", cursor: "pointer", fontSize: 12,
                fontFamily: "monospace", fontWeight: isSelected ? 700 : 400
              }}>
                {s.ticker}
              </button>
            );
          })}
        </div>
      </div>

      {/* Comparison table */}
      {compared.length === 0 ? (
        <div style={{ color: "#374151", textAlign: "center", padding: "50px 0", fontSize: 13 }}>בחר מניות לעיל להשוואה</div>
      ) : (
        <div style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 12, overflow: "hidden" }}>
          {/* Header row */}
          <div style={{ display: "grid", gridTemplateColumns: `180px repeat(${compared.length}, 1fr)`, borderBottom: "1px solid #1F2937" }}>
            <div style={{ padding: "14px 16px", color: "#4B5563", fontSize: 10, letterSpacing: 1.5 }}>שדה</div>
            {compared.map(s => {
              const sector = SECTORS[s.sector];
              return (
                <div key={s.id} style={{ padding: "12px 16px", textAlign: "center", borderRight: "1px solid #1F2937", background: `${sector?.color}08` }}>
                  <div style={{ fontFamily: "monospace", color: "#F9FAFB", fontWeight: 700, fontSize: 16 }}>{s.ticker}</div>
                  <div style={{ color: sector?.color, fontSize: 10, marginTop: 2 }}>{sector?.icon} {sector?.label}</div>
                  <button onClick={() => toggle(s.id)} style={{ background: "none", border: "none", color: "#374151", cursor: "pointer", fontSize: 12, marginTop: 4 }}>✕</button>
                </div>
              );
            })}
          </div>
          {/* Data rows */}
          {FIELDS.map((field, fi) => (
            <div key={field.key} style={{ display: "grid", gridTemplateColumns: `180px repeat(${compared.length}, 1fr)`, borderBottom: fi < FIELDS.length - 1 ? "1px solid #0F1117" : "none", background: fi % 2 === 0 ? "transparent" : "#080B1240" }}>
              <div style={{ padding: "12px 16px", color: "#6B7280", fontSize: 12 }}>{field.label}</div>
              {compared.map(s => {
                const best = isBest(field, s);
                const v = getVal(s, field);
                return (
                  <div key={s.id} style={{ padding: "12px 16px", textAlign: "center", borderRight: "1px solid #0F1117", background: best ? "#10B98108" : "transparent" }}>
                    <span style={{ color: best ? "#10B981" : "#D1D5DB", fontFamily: "monospace", fontSize: 13, fontWeight: best ? 700 : 400 }}>
                      {field.format(v, s)}
                    </span>
                    {best && <span style={{ fontSize: 10, marginRight: 4 }}>⭐</span>}
                  </div>
                );
              })}
            </div>
          ))}
          {/* Thesis comparison */}
          <div style={{ padding: 16, borderTop: "1px solid #1F2937" }}>
            <div style={{ color: "#4B5563", fontSize: 10, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 12 }}>תזה</div>
            <div style={{ display: "grid", gridTemplateColumns: `repeat(${compared.length}, 1fr)`, gap: 12 }}>
              {compared.map(s => {
                const sector = SECTORS[s.sector];
                return (
                  <div key={s.id} style={{ background: `${sector?.color}08`, border: `1px solid ${sector?.color}20`, borderRadius: 8, padding: 12 }}>
                    <div style={{ fontFamily: "monospace", color: sector?.color, fontWeight: 700, marginBottom: 6, fontSize: 12 }}>{s.ticker}</div>
                    <div style={{ color: "#9CA3AF", fontSize: 11, lineHeight: 1.6 }}>{s.thesis || "—"}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}



// ─────────────────────────────────────────────
// DAILY UPDATE TAB
// ─────────────────────────────────────────────
function DailyUpdateTab({ stocks, dailyUpdates }) {
  const [filter, setFilter] = useState("all");
  const today = new Date().toISOString().split("T")[0];

  const TYPE_CONFIG = {
    "מחיר":    { icon: "📈", color: "#10B981" },
    "חדשה":   { icon: "📰", color: "#38BDF8" },
    "אזהרה":  { icon: "⚠️", color: "#EF4444" },
    "ניתוח":  { icon: "💡", color: "#818CF8" },
    "קטליסט": { icon: "🎯", color: "#F97316" },
  };

  const IMPACT_CONFIG = {
    "חיובי":       { color: "#10B981", bg: "#10B98115" },
    "שלילי":       { color: "#EF4444", bg: "#EF444415" },
    "ניטרלי":      { color: "#6B7280", bg: "#6B728015" },
    "צריך מעקב":  { color: "#F59E0B", bg: "#F59E0B15" },
  };

  const PRIORITY_CONFIG = {
    "דחוף":  { color: "#EF4444", dot: "🔴" },
    "חשוב":  { color: "#F59E0B", dot: "🟡" },
    "מידע":  { color: "#10B981", dot: "🟢" },
  };

  const todayUpdates = dailyUpdates.filter(u => u.date === today);
  const allUpdates = [...dailyUpdates].sort((a, b) => new Date(b.date) - new Date(a.date));

  const filtered = (filter === "all" ? allUpdates : allUpdates.filter(u => u.type === filter))
    .slice(0, 50);

  const urgent = todayUpdates.filter(u => u.priority === "דחוף");
  const byTicker = {};
  todayUpdates.forEach(u => {
    if (!byTicker[u.ticker]) byTicker[u.ticker] = [];
    byTicker[u.ticker].push(u);
  });

  return (
    <div style={{ direction: "rtl" }}>
      {/* Today summary bar */}
      <div style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 12, padding: 18, marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ color: "#F9FAFB", fontWeight: 600, fontSize: 15 }}>
            📅 עדכוני היום — {new Date().toLocaleDateString("he-IL", { weekday: "long", day: "numeric", month: "long" })}
          </div>
          <div style={{ color: "#4B5563", fontSize: 12 }}>{todayUpdates.length} עדכונים</div>
        </div>

        {urgent.length > 0 && (
          <div style={{ background: "#EF444410", border: "1px solid #EF444440", borderRadius: 8, padding: 12, marginBottom: 12 }}>
            <div style={{ color: "#EF4444", fontSize: 11, fontWeight: 700, marginBottom: 8 }}>🔴 דחוף — דורש תשומת לב</div>
            {urgent.map((u, i) => (
              <div key={i} style={{ color: "#FCA5A5", fontSize: 12, marginBottom: 4 }}>
                <span style={{ fontFamily: "monospace", fontWeight: 700 }}>{u.ticker}</span> — {u.content}
              </div>
            ))}
          </div>
        )}

        {todayUpdates.length === 0 && (
          <div style={{ color: "#374151", fontSize: 13, textAlign: "center", padding: "20px 0" }}>
            אין עדכונים להיום עדיין — שלח "עדכן" בצאט ואמלא
          </div>
        )}

        {/* Ticker pills */}
        {Object.keys(byTicker).length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {Object.entries(byTicker).map(([ticker, updates]) => {
              const stock = stocks.find(s => s.ticker === ticker);
              const sector = stock ? SECTORS[stock.sector] : null;
              const priceUpdate = updates.find(u => u.type === "מחיר");
              const change = priceUpdate?.change;
              return (
                <div key={ticker} style={{
                  background: `${sector?.color || "#6B7280"}12`,
                  border: `1px solid ${sector?.color || "#6B7280"}40`,
                  borderRadius: 8, padding: "8px 14px"
                }}>
                  <div style={{ fontFamily: "monospace", color: "#F9FAFB", fontWeight: 700, fontSize: 13 }}>{ticker}</div>
                  {change !== undefined && (
                    <div style={{ color: change >= 0 ? "#10B981" : "#EF4444", fontFamily: "monospace", fontSize: 12, fontWeight: 700 }}>
                      {change >= 0 ? "+" : ""}{change?.toFixed(2)}%
                    </div>
                  )}
                  <div style={{ color: "#4B5563", fontSize: 10 }}>{updates.length} עדכון{updates.length > 1 ? "ים" : ""}</div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Filter tabs */}
      <div style={{ display: "flex", gap: 6, marginBottom: 16, flexWrap: "wrap" }}>
        {[["all", "הכל"], ["מחיר", "📈 מחירים"], ["חדשה", "📰 חדשות"], ["אזהרה", "⚠️ אזהרות"], ["ניתוח", "💡 ניתוחים"], ["קטליסט", "🎯 קטליסטים"]].map(([key, label]) => (
          <button key={key} onClick={() => setFilter(key)} style={{
            background: filter === key ? "#1F2937" : "none",
            border: `1px solid ${filter === key ? "#374151" : "#1F2937"}`,
            color: filter === key ? "#F9FAFB" : "#6B7280",
            borderRadius: 7, padding: "6px 12px", cursor: "pointer", fontSize: 12
          }}>{label}</button>
        ))}
      </div>

      {/* Updates feed */}
      {filtered.length === 0 ? (
        <div style={{ color: "#374151", textAlign: "center", padding: "60px 0", border: "1px dashed #1F2937", borderRadius: 10 }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📭</div>
          <div>אין עדכונים עדיין</div>
          <div style={{ fontSize: 12, marginTop: 6, color: "#2D3748" }}>שלח "עדכן מחירים וחדשות" בצאט הראשי</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {filtered.map((u, i) => {
            const typeConf = TYPE_CONFIG[u.type] || { icon: "📋", color: "#6B7280" };
            const impactConf = IMPACT_CONFIG[u.impact] || { color: "#6B7280", bg: "#6B728015" };
            const priorityConf = PRIORITY_CONFIG[u.priority] || { color: "#6B7280", dot: "⚪" };
            const stock = stocks.find(s => s.ticker === u.ticker);
            const sector = stock ? SECTORS[stock.sector] : null;
            const isToday = u.date === today;

            return (
              <div key={i} style={{
                background: isToday ? "#0D1117" : "#080B12",
                border: `1px solid ${impactConf.color}30`,
                borderRight: `3px solid ${impactConf.color}`,
                borderRadius: 10, padding: 16,
                opacity: isToday ? 1 : 0.7
              }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 18 }}>{typeConf.icon}</span>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        {u.ticker && (
                          <span style={{ fontFamily: "monospace", color: sector?.color || "#F9FAFB", fontWeight: 700, fontSize: 14 }}>{u.ticker}</span>
                        )}
                        {sector && <span style={{ color: sector.color, fontSize: 11 }}>{sector.icon} {sector.label}</span>}
                        <span style={{ background: `${impactConf.color}20`, color: impactConf.color, borderRadius: 5, padding: "1px 7px", fontSize: 10 }}>{u.impact}</span>
                      </div>
                      <div style={{ color: "#F9FAFB", fontSize: 13, fontWeight: 600, marginTop: 3 }}>{u.title}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <span style={{ fontSize: 14 }}>{priorityConf.dot}</span>
                    {u.change !== undefined && (
                      <span style={{ fontFamily: "monospace", fontWeight: 700, color: u.change >= 0 ? "#10B981" : "#EF4444", fontSize: 13 }}>
                        {u.change >= 0 ? "+" : ""}{u.change?.toFixed(2)}%
                      </span>
                    )}
                    <span style={{ color: "#374151", fontSize: 10 }}>{u.date}</span>
                  </div>
                </div>

                {u.content && (
                  <div style={{ color: "#9CA3AF", fontSize: 12, lineHeight: 1.7, marginBottom: u.action ? 10 : 0 }}>{u.content}</div>
                )}

                {u.action && (
                  <div style={{ background: "#818CF820", border: "1px solid #818CF840", borderRadius: 7, padding: "8px 12px", fontSize: 12, color: "#818CF8" }}>
                    💡 פעולה מוצעת: {u.action}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}


// ─────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────
export default function StockBank() {
  const [stocks, setStocks] = useState([]);
  const [portfolio, setPortfolio] = useState({});
  const [trades, setTrades] = useState([]);
  const [dailyUpdates, setDailyUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("bank");
  const [filterSector, setFilterSector] = useState("all");
  const [filterRisk, setFilterRisk] = useState("all");
  const [filterLayer, setFilterLayer] = useState("all");
  const [search, setSearch] = useState("");

  // Load
  useEffect(() => {
    (async () => {
      try {
        const r1 = await window.storage.get(STORAGE_KEY, true);
        if (r1?.value) {
          const stored = JSON.parse(r1.value);
          if (stored.length > 0) {
            // Merge: use stored prices/data but fill in any new stocks from NOTION_STOCKS
            const storedMap = {};
            stored.forEach(s => storedMap[s.ticker] = s);
            const merged = NOTION_STOCKS.map(ns => storedMap[ns.ticker] ? {...ns, currentPrice: storedMap[ns.ticker].currentPrice} : ns);
            setStocks(merged);
          } else {
            setStocks(NOTION_STOCKS);
            await window.storage.set(STORAGE_KEY, JSON.stringify(NOTION_STOCKS), true);
          }
        } else {
          setStocks(NOTION_STOCKS);
          await window.storage.set(STORAGE_KEY, JSON.stringify(NOTION_STOCKS), true);
        }
      } catch { setStocks(NOTION_STOCKS); }
      try { const r2 = await window.storage.get(PORTFOLIO_KEY, true); if (r2?.value) setPortfolio(JSON.parse(r2.value)); } catch {}
      try { const r3 = await window.storage.get(TRADES_KEY, true); if (r3?.value) setTrades(JSON.parse(r3.value)); } catch {}
      try { const r4 = await window.storage.get(DAILY_KEY, true); if (r4?.value) setDailyUpdates(JSON.parse(r4.value)); } catch {}
      setLoading(false);
    })();
  }, []);

  const saveStocks = useCallback(async (d) => { try { await window.storage.set(STORAGE_KEY, JSON.stringify(d), true); } catch {} }, []);

  const savePortfolio = useCallback(async (d) => { try { await window.storage.set(PORTFOLIO_KEY, JSON.stringify(d), true); } catch {} }, []);
  const saveTrades = useCallback(async (d) => { try { await window.storage.set(TRADES_KEY, JSON.stringify(d), true); } catch {} }, []);

  const deleteStock = (id) => { const u = stocks.filter(s => s.id !== id); setStocks(u); saveStocks(u); };

  const filtered = stocks.filter(s => {
    if (filterSector !== "all" && s.sector !== filterSector) return false;
    if (filterRisk !== "all" && s.risk !== filterRisk) return false;
    if (filterLayer !== "all" && s.layer !== filterLayer) return false;
    if (search && !s.ticker.toUpperCase().includes(search.toUpperCase()) && !s.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const totalWeight = stocks.reduce((s, x) => s + (parseFloat(x.weight) || 0), 0);
  const byLayer = Object.keys(LAYER_CONFIG).reduce((a, k) => { a[k] = stocks.filter(s => s.layer === k).length; return a; }, {});
  const upcomingEarnings = stocks.filter(s => { const d = daysUntil(s.earningsDate); return d !== null && d >= 0 && d <= 14; }).sort((a, b) => daysUntil(a.earningsDate) - daysUntil(b.earningsDate));
  const pendingTrades = trades.filter(t => t.status === "suggestion").length;

  // Portfolio data per stock
  const getPortfolioData = (ticker) => {
    return Object.entries(portfolio).flatMap(([memberId, positions]) => {
      const pos = positions[ticker];
      if (!pos || !pos.allocation) return [];
      return [{ member: memberId, ...pos }];
    });
  };

  const btnStyle = (active, color = "#6366F1") => ({
    background: active ? `${color}20` : "none",
    border: `1px solid ${active ? color : "#1F2937"}`,
    color: active ? color : "#6B7280",
    borderRadius: 7, padding: "5px 12px", cursor: "pointer", fontSize: 11, transition: "all 0.15s"
  });

  const navTab = (id, label, badge) => (
    <button key={id} onClick={() => setActiveTab(id)} style={{
      background: activeTab === id ? "#1F2937" : "none",
      border: `1px solid ${activeTab === id ? "#374151" : "transparent"}`,
      color: activeTab === id ? "#F9FAFB" : "#6B7280",
      borderRadius: 8, padding: "8px 18px", cursor: "pointer", fontSize: 13, fontWeight: activeTab === id ? 600 : 400, position: "relative"
    }}>
      {label}
      {badge > 0 && <span style={{ position: "absolute", top: -4, right: -4, background: "#EF4444", color: "white", borderRadius: "50%", width: 15, height: 15, fontSize: 9, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 }}>{badge}</span>}
    </button>
  );

  if (loading) return (
    <div style={{ background: "#080B12", minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ color: "#6366F1", fontFamily: "monospace" }}>טוען...</div>
    </div>
  );

  return (
    <div style={{ background: "#080B12", minHeight: "100vh", fontFamily: "'Heebo', sans-serif", direction: "rtl", color: "#F9FAFB", padding: "24px 20px" }}>
      <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@300;400;500;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />

      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        {/* HEADER */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
          <div>
            <div style={{ color: "#6366F1", fontSize: 10, letterSpacing: 3, textTransform: "uppercase", marginBottom: 6 }}>⬡ STOCK INTELLIGENCE BANK</div>
            <h1 style={{ margin: 0, fontSize: 28, fontWeight: 700 }}>בנק המניות</h1>
            <div style={{ color: "#4B5563", fontSize: 12, marginTop: 4 }}>{stocks.length} מניות · 3 חברי צוות · יעד 30% שנתי</div>
          </div>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            {MEMBERS.map(m => <MemberAvatar key={m.id} member={m} size={32} />)}
          </div>
        </div>

        {/* NAV TABS */}
        <div style={{ display: "flex", gap: 6, marginBottom: 20, borderBottom: "1px solid #1F2937", paddingBottom: 12 }}>
          {navTab("bank", "📊 בנק מניות", 0)}
          {navTab("portfolio", "💼 תיקים אישיים", 0)}
          {navTab("trades", "⚡ טריידים", pendingTrades)}
          {navTab("heatmap", "🔥 היט-מאפ", 0)}
          {navTab("calc", "🧮 מחשבון R:R", 0)}
          {navTab("calendar", "📅 יומן דוחות", 0)}
          {navTab("compare", "⚖️ השוואה", 0)}
          {navTab("daily", "📰 עדכון יומי", dailyUpdates.filter(u => u.date === new Date().toISOString().split("T")[0]).length)}
        </div>

        {/* BANK TAB */}
        {activeTab === "bank" && (
          <>
            {/* Stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 20 }}>
              <StatCard label="סה״כ מניות" value={stocks.length} sub={`${filtered.length} מוצגות`} color="#6366F1" />
              <StatCard label="ליבה·צמיחה·ספק·המתנה" value={`${byLayer.core}·${byLayer.growth}·${byLayer.speculative}·${byLayer.waiting}`} sub="חלוקת שכבות" color="#F59E0B" />
              <StatCard label="דוחות קרובים (14י')" value={upcomingEarnings.length} sub={upcomingEarnings.slice(0,2).map(s => s.ticker).join(", ") || "—"} color="#F97316" />
              <StatCard label="טריידים ממתינים" value={pendingTrades} sub={pendingTrades > 0 ? "⚡ יש להצביע" : "הכל נקי"} color={pendingTrades > 0 ? "#EF4444" : "#10B981"} />
            </div>

            {/* Sector chips */}
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
              {Object.entries(SECTORS).map(([k, v]) => {
                const count = stocks.filter(s => s.sector === k).length;
                return (
                  <div key={k} onClick={() => setFilterSector(filterSector === k ? "all" : k)} style={{
                    background: filterSector === k ? `${v.color}18` : "#0A0D14",
                    border: `${filterSector === k ? "2px" : "1px"} solid ${filterSector === k ? v.color : v.color + "50"}`,
                    borderRadius: 9, padding: "8px 14px", display: "flex", alignItems: "center", gap: 8, cursor: "pointer"
                  }}>
                    <span style={{ fontSize: 16 }}>{v.icon}</span>
                    <div>
                      <div style={{ color: v.color, fontSize: 12, fontWeight: 600 }}>{v.label}</div>
                      <div style={{ color: "#6B7280", fontSize: 10 }}>{v.owner} · {count}</div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Filters */}
            <div style={{ display: "flex", gap: 6, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="חיפוש..." style={{ background: "#0A0D14", border: "1px solid #1F2937", borderRadius: 7, color: "#F9FAFB", padding: "6px 12px", fontSize: 12, outline: "none", fontFamily: "inherit", width: 160 }} />
              <div style={{ display: "flex", gap: 4 }}>
                <button style={btnStyle(filterLayer === "all")} onClick={() => setFilterLayer("all")}>הכל</button>
                {Object.entries(LAYER_CONFIG).map(([k, v]) => <button key={k} style={btnStyle(filterLayer === k, v.color)} onClick={() => setFilterLayer(filterLayer === k ? "all" : k)}>{v.label}</button>)}
              </div>
              <div style={{ display: "flex", gap: 4 }}>
                {Object.entries(RISK_CONFIG).map(([k, v]) => <button key={k} style={btnStyle(filterRisk === k, v.color)} onClick={() => setFilterRisk(filterRisk === k ? "all" : k)}>{v.label}</button>)}
              </div>
            </div>

            {/* Table header */}
            {filtered.length > 0 && (
              <div style={{ display: "grid", gridTemplateColumns: "76px 1fr 90px 88px 76px 70px 70px 34px", padding: "6px 14px", gap: 10, marginBottom: 6 }}>
                {["טיקר", "חברה", "סיכון", "שכבה", "אפסייד", "P/E", "יעד אנל'", ""].map((h, i) => (
                  <div key={i} style={{ color: "#374151", fontSize: 9, letterSpacing: 1.5, textTransform: "uppercase" }}>{h}</div>
                ))}
              </div>
            )}

            {/* Stock rows */}
            {filtered.length === 0
              ? <div style={{ textAlign: "center", padding: "60px 0", color: "#374151", border: "1px dashed #1F2937", borderRadius: 10 }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>📊</div>
                  <div>אין תוצאות</div>
                </div>
              : filtered.map(s => <StockRow key={s.id} stock={s} onDelete={deleteStock} portfolioData={getPortfolioData(s.ticker)} />)
            }
          </>
        )}

        {activeTab === "portfolio" && (
          <PortfolioTab stocks={stocks} portfolio={portfolio} setPortfolio={setPortfolio} savePortfolio={savePortfolio} />
        )}

        {activeTab === "trades" && (
          <TradesTab stocks={stocks} trades={trades} setTrades={setTrades} saveTrades={saveTrades} />
        )}

        {activeTab === "heatmap" && (
          <RiskHeatmapTab stocks={stocks} />
        )}

        {activeTab === "calc" && (
          <RRCalcTab stocks={stocks} />
        )}

        {activeTab === "calendar" && (
          <EarningsCalendarTab stocks={stocks} />
        )}

        {activeTab === "compare" && (
          <CompareTab stocks={stocks} />
        )}

        {activeTab === "daily" && (
          <DailyUpdateTab stocks={stocks} dailyUpdates={dailyUpdates} />
        )}
      </div>
    </div>
  );
}
